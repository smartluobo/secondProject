CREATE TRIGGER CHANGECONTRACT_TRIGGER
BEFORE INSERT
  ON DK_PAY_CHANGECONTRACT
FOR EACH ROW
  begin
  select to_char(sysdate, 'yyyymmdd') ||
         lpad(to_char(case
                        when SEQ_DK_CONTRACT.nextval > 9999999999 then
                         mod(SEQ_DK_CONTRACT.nextval, 10000000000)
                        else
                         SEQ_DK_CONTRACT.nextval
                      end),
              10,
              '0')
    into:new.serialno
  from dual;
end;
/
