CREATE TRIGGER DK_ICBC_CHARGE_TRIGGER
AFTER UPDATE
  ON DK_ICBC_BATCHCHARGE_DETAIL
FOR EACH ROW
  begin
  update dk_charge a
     set a.result = (case
                      when :new.PAYSTATUS = '3' then
                       '0000'
                      when :new.PAYSTATUS in ('4','5') then
                       '1111'
                      else
                       '1001'
                    end),
         a.msg    = :new.DKREMARK,
         a.dkcode = :new.DKCODE
   where a.lasserialno = :new.LASSERIALNO
     and a.paychannel = '100';
end;
/
