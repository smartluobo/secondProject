CREATE TRIGGER DK__KFT_BATCHCHARGE_TRIGGER
BEFORE INSERT
  ON DK_KFT_BATCHCHARGE_DETAIL
FOR EACH ROW
  begin
  select to_char(sysdate, 'yyyymmdd') ||
         lpad(to_char(case
                        when SEQ_DK_PAY_DETAIL.nextval > 9999999999 then
                         mod(SEQ_DK_PAY_DETAIL.nextval, 10000000000)
                        else
                         SEQ_DK_PAY_DETAIL.nextval
                      end),
              10,
              '0')
    into:new.serialno
  from dual;
end;
/
