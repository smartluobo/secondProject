CREATE TRIGGER DK_KFT_NEW_REALTIME_TRIGGER
BEFORE INSERT
  ON DK_KFT_NEW_RT_CHARGE_DETAIL
FOR EACH ROW
  begin
  select t.serialno into:new.serialno from dk_charge t where t.lasserialno=:new.lasserialno;
end;
/
