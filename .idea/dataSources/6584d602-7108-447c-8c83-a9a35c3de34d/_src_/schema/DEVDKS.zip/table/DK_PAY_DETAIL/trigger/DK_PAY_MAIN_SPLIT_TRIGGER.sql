CREATE TRIGGER DK_PAY_MAIN_SPLIT_TRIGGER
AFTER INSERT
  ON DK_PAY_DETAIL
FOR EACH ROW
  begin
 INSERT INTO DK_PAY_MAIN_SPLIT(
        SERIALNO,
        OBJECTNO,
        DEALDATE,
        INFOTYPE,
        PAYCHANNEL,
        PAYSTATUS,
        CONTRANCTNO,
        CREATETIME,
        TASKNO)
 values (
        :new.SERIALNO,
        :new.OBJECTNO,
        :new.DEALDATE,
        :new.INFOTYPE,
        :new.PAYCHANNEL,
        :new.PAYSTATUS,
        :new.CONTRANCTNO,
        :new.CREATETIME,
        :new.TASKNO);
end;
/
