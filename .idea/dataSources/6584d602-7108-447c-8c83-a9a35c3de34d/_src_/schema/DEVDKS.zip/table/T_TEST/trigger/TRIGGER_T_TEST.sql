CREATE TRIGGER TRIGGER_T_TEST
BEFORE INSERT OR UPDATE
  ON T_TEST
FOR EACH ROW
  begin
 select sysdate into:new.createdate from dual;
end;
/
