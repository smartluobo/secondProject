CREATE TRIGGER TRIGGER_T_TEST1
BEFORE UPDATE
  ON T_TEST
FOR EACH ROW
  declare
   curdate date;
begin
  select sysdate into curdate from dual;
  :new.createdate := curdate;
end;
/
