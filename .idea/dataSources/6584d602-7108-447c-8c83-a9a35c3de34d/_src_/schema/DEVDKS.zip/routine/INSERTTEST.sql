CREATE procedure inserttest
as
  casekey char(14);
  username varchar2(32);
  useraddr varchar2(32);
begin
  for i in 1..100 loop
    casekey := 'TMP'||lpad(i,7,0);  
    username := 'NAME'||lpad(i,7,0);
    useraddr := 'ADDR'||lpad(i,7,0);
    insert into test values(casekey, username, useraddr);
  end loop;
  commit;
end;

/
