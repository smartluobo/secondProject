CREATE procedure lpmtest2
as
  cursor  curname is  select name from dk_test11;
  rec curname%ROWTYPE;
begin
  open curname;
  loop
    fetch curname into rec;
       MERGE INTO dk_test12 t USING  (select count(1) as cnt12 from  dk_test12 a where a.name = rec.name) w
            ON (w.cnt12>0)
     	WHEN NOT MATCHED THEN
        INSERT (name
        )
        values(
          rec.name
          );
  end loop;
  commit;
  close curname;
end;
/
