CREATE procedure proc_xunlian_detail_bInsert
as serialnoKey char(40);
begin
  for i in 1..10000 loop
    serialnoKey:= to_char(sysdate,'yyyymmdd') ||lpad(to_char(case when SEQ_DK_ICBC_CHARGE_SEND.nextval>9999999999 then mod(SEQ_DK_ICBC_CHARGE_SEND.nextval,10000000000)
              else SEQ_DK_ICBC_CHARGE_SEND.nextval end),10,'0');
    insert into dk_xunlian_detail( SERIALNO ) values(serialnoKey);
  end loop;
  commit;
end;
/
