CREATE procedure proc_umsdemo_upstate
as
begin
  for i in 1..10000 loop
    insert into dk_ums_trans (BUSINESS_CODE, MERCHANT_ID, SUBMIT_TIME, TERM_CODE, ACCOUNT_TYPE, ACCOUNT_NO, ACCOUNT_NAME, ACCOUNT_PROP, AMOUNT, BANK_CODE, CURRENCY, CUST_USERID, TEL, TIME_CONSUM, SERIALNO, PAYSTATUS)
    values ('', '', '', null, '00', '6216731111111111123', '中行', '0', '200', '0105', 'CNY', '370101198001013000', '13800138000', '',  to_char(sysdate,'yyyymmdd')
              ||lpad(to_char(case when SEQ_DK_ICBC_CONTRACT.nextval>9999999999 then mod(SEQ_DK_ICBC_CONTRACT.nextval,10000000000)
              else SEQ_DK_ICBC_CONTRACT.nextval end),10,'0'),'0');
  end loop;
  commit;
end;
/
