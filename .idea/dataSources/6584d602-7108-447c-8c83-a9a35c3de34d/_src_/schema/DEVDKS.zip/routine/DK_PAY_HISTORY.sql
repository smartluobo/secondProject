CREATE PROCEDURE DK_PAY_HISTORY(p_taskno varchar2) AS
BEGIN
  INSERT INTO DK_PAY_DETAIL_HIST
    (serialno,
     objectno,
     dealdate,
     businessdate,
     batchtranstype,
     infotype,
     paychannel,
     paycurrency,
     payamt,
     payacctno,
     payacctname,
     payacctbankno,
     payacctbankname,
     acpbankno,
     acpbankname,
     acpacctno,
     acpacctname,
     paystatus,
     customerid,
     contranctno,
     createtime,
     createdby,
     updatetime,
     updateby,
     LASSERIALNO,
     taskno)
    SELECT serialno,
           objectno,
           dealdate,
           businessdate,
           batchtranstype,
           infotype,
           paychannel,
           paycurrency,
           payamt,
           payacctno,
           payacctname,
           payacctbankno,
           payacctbankname,
           acpbankno,
           acpbankname,
           acpacctno,
           acpacctname,
           paystatus,
           customerid,
           contranctno,
           createtime,
           createdby,
           updatetime,
           updateby,
           LASSERIALNO,
           taskno
      FROM DK_PAY_DETAIL
     WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
       AND PAYSTATUS in ('4', '5') and taskno=p_taskno;

  INSERT INTO DK_PAY_SPLIT_HIST
    (serialno,
     objectno,
     dealdate,
     infotype,
     paychannel,
     paystatus,
     contranctno,
     threadno,
     createtime,
     taskno)
    SELECT serialno,
           objectno,
           dealdate,
           infotype,
           paychannel,
           paystatus,
           contranctno,
           threadno,
           createtime,
           taskno
      FROM DK_PAY_MAIN_SPLIT
     WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
       AND PAYSTATUS in ('4', '5') and taskno=p_taskno;

  delete from DK_PAY_DETAIL
   WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
     AND PAYSTATUS in ('4', '5') and taskno=p_taskno;
  delete from DK_PAY_MAIN_SPLIT
   WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
     AND PAYSTATUS in ('4', '5') and taskno=p_taskno;

--将签约数据放入签约历史表
  INSERT INTO Dk_Pay_Contract_Hist
    (serialno,
     objectno,
     dealdate,
     infotype,
     payacctno,
     payacctname,
     payacctbankno,
     payacctbankname,
     changestatus,
     signstatus,
     remark,
     createtime,
     createdby,
     updatetime,
     updateby,
     taskno)
    SELECT serialno,
           objectno,
           dealdate,
           infotype,
           payacctno,
           payacctname,
           payacctbankno,
           payacctbankname,
           changestatus,
           signstatus,
           remark,
           createtime,
           createdby,
           updatetime,
           updateby,
           taskno
      FROM Dk_Pay_Changecontract
     WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
       AND signstatus in ('3', '4') and taskno=p_taskno;

  INSERT INTO Dk_Pay_Contract_Hist
    (serialno,
     objectno,
     dealdate,
     infotype,
     payacctno,
     payacctname,
     payacctbankno,
     payacctbankname,
     changestatus,
     signstatus,
     remark,
     createtime,
     createdby,
     updatetime,
     updateby,
     taskno)
    SELECT serialno,
           objectno,
           dealdate,
           infotype,
           payacctno,
           payacctname,
           payacctbankno,
           payacctbankname,
           changestatus,
           signstatus,
           remark,
           createtime,
           createdby,
           updatetime,
           updateby,
           taskno
      FROM Dk_Pay_Newcontract
     WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
       AND signstatus in ('3', '4') and taskno=p_taskno;
--清除放入历史表的数据
  delete from Dk_Pay_Changecontract
   WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
     AND signstatus in ('3', '4') and taskno=p_taskno;
  delete from Dk_Pay_Newcontract
   WHERE DEALDATE <= TO_CHAR(SYSDATE - 1, 'YYYY/MM/DD')
     AND signstatus in ('3', '4') and taskno=p_taskno;
commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END;

/
