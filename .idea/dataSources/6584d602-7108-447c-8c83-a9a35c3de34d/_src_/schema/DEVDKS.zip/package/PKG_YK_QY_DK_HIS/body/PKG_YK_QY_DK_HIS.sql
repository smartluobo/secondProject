CREATE PACKAGE BODY PKG_YK_QY_DK_HIS IS

  --============================易极付银行卡验证数据转移begin================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易极付银行卡验证明细数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_VALIDATE_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_VALIDATE_DETAIL_HIS
      (serialno,
       outid,
       realname,
       certno,
       bankcardtype,
       bankcode,
       servicetype,
       bankcardno,
       mobileno,
       success,
       resultmessage,
       status,
       infotype,
       contractno,
       customerid,
       createddate,
       createdtby,
       resultcode,
       taskno)
      SELECT serialno,
             outid,
             realname,
             certno,
             bankcardtype,
             bankcode,
             servicetype,
             bankcardno,
             mobileno,
             success,
             resultmessage,
             status,
             infotype,
             contractno,
             customerid,
             createddate,
             createdtby,
             resultcode,
             taskno
        FROM DK_VALIDATE_DETAIL DVD
       WHERE TO_CHAR(DVD.CREATEDDATE, 'YYYY/MM/DD') <
             TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DVD.STATUS = '2'
         AND DVD.TASKNO = p_taskno;
    DELETE FROM DK_VALIDATE_DETAIL DDVD
     WHERE TO_CHAR(DDVD.CREATEDDATE, 'YYYY/MM/DD') <
           TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDVD.STATUS = '2'
       AND DDVD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_VALIDATE_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易极付银行卡验证接收数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_VALIDATE_RECEIVE_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_VALIDATE_RECEIVE_HIS
      (serialno,
       realname,
       certno,
       bankcardtype,
       bankcode,
       servicetype,
       bankcardno,
       mobileno,
       verifystatus,
       success,
       service,
       channel,
       createddate,
       createdtby,
       sign_type,
       protocol,
       orderno,
       partnerid,
       resultcode,
       resultmessage,
       starttime,
       endtime,
       sendtime,
       querynum,
       taskno)
      SELECT serialno,
             realname,
             certno,
             bankcardtype,
             bankcode,
             servicetype,
             bankcardno,
             mobileno,
             verifystatus,
             success,
             service,
             channel,
             createddate,
             createdtby,
             sign_type,
             protocol,
             orderno,
             partnerid,
             resultcode,
             resultmessage,
             starttime,
             endtime,
             sendtime,
             querynum,
             taskno
        FROM DK_VALIDATE_RECEIVE DVR
       WHERE TO_CHAR(DVR.CREATEDDATE, 'YYYY/MM/DD') <
             TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DVR.TASKNO = p_taskno;
    DELETE FROM DK_VALIDATE_RECEIVE DDVR
     WHERE TO_CHAR(DDVR.CREATEDDATE, 'YYYY/MM/DD') <
           TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDVR.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_VALIDATE_RECEIVE_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易极付银行卡验证已处理异常数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_VALIDATE_EXCEPTION_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_VALIDATE_EXCEPTION_HIS
      (outid,
       realname,
       certno,
       bankcardtype,
       bankcode,
       servicetype,
       bankcardno,
       mobileno,
       status,
       createddate,
       createdtby,
       taskno)
      SELECT outid,
             realname,
             certno,
             bankcardtype,
             bankcode,
             servicetype,
             bankcardno,
             mobileno,
             status,
             createddate,
             createdtby,
             taskno
        FROM DK_VALIDATE_EXCEPTION DVE
       WHERE TO_CHAR(DVE.CREATEDDATE, 'YYYY/MM/DD') <
             TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DVE.STATUS = '1'
         AND DVE.TASKNO = p_taskno;
    DELETE FROM DK_VALIDATE_EXCEPTION DDVE
     WHERE TO_CHAR(DDVE.CREATEDDATE, 'YYYY/MM/DD') <
           TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDVE.STATUS = '1'
       AND DDVE.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_VALIDATE_EXCEPTION_HIS;
  --============================易极付银行卡验证数据转移end================================

  --============================快付通实时签约合同数据转移begin================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时合同数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_PAY_SIGNCONTRACT_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_SIGNCONTRACT_HIS
      (serialno,
       objectno,
       dealdate,
       infotype,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       changestatus,
       signstatus,
       createtime,
       createdby,
       updatetime,
       updateby,
       remark,
       oldpayacctbankno,
       outbatno,
       batno,
       result,
       msg,
       channel,
       bankcode,
       sendflag,
       distribute,
       taskno)
      SELECT serialno,
             objectno,
             dealdate,
             infotype,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             changestatus,
             signstatus,
             createtime,
             createdby,
             updatetime,
             updateby,
             remark,
             oldpayacctbankno,
             outbatno,
             batno,
             result,
             msg,
             channel,
             bankcode,
             sendflag,
             distribute,
             taskno
        FROM DK_PAY_SIGNCONTRACT DPSC
       WHERE DPSC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DPSC.RESULT in ('3', '4')
         AND DPSC.TASKNO = p_taskno;
    DELETE FROM DK_PAY_SIGNCONTRACT DDPSC
     WHERE DDPSC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDPSC.RESULT in ('3', '4')
       AND DDPSC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_PAY_SIGNCONTRACT_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时新签合同数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_PAY_NEWCONTRACT_HIS(p_taskno IN VARCHAR2,
                                       p_days   IN NUMBER) IS
  BEGIN
    INSERT INTO DK_PAY_CONTRACT_HIST
      (serialno,
       objectno,
       dealdate,
       infotype,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       changestatus,
       signstatus,
       remark,
       createtime,
       createdby,
       updatetime,
       updateby,
       taskno)
      SELECT serialno,
             objectno,
             dealdate,
             infotype,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             changestatus,
             signstatus,
             remark,
             createtime,
             createdby,
             updatetime,
             updateby,
             taskno
        FROM DK_PAY_NEWCONTRACT DPNC
       WHERE DPNC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DPNC.SIGNSTATUS in ('3', '4')
         AND DPNC.TASKNO = p_taskno;
    DELETE FROM DK_PAY_NEWCONTRACT DDPNC
     WHERE DDPNC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDPNC.SIGNSTATUS in ('3', '4')
       AND DDPNC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_PAY_NEWCONTRACT_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时变更合同数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_PAY_CHANGECONTRACT_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_CONTRACT_HIST
      (serialno,
       objectno,
       dealdate,
       infotype,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       changestatus,
       signstatus,
       remark,
       createtime,
       createdby,
       updatetime,
       updateby,
       oldpayacctbankno,
       taskno)
      SELECT serialno,
             objectno,
             dealdate,
             infotype,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             changestatus,
             signstatus,
             remark,
             createtime,
             createdby,
             updatetime,
             updateby,
             oldpayacctbankno,
             taskno
        FROM DK_PAY_CHANGECONTRACT DPCC
       WHERE DPCC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DPCC.SIGNSTATUS in ('3', '4')
         AND DPCC.TASKNO = p_taskno;
    DELETE FROM DK_PAY_CHANGECONTRACT DDPCC
     WHERE DDPCC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDPCC.SIGNSTATUS in ('3', '4')
       AND DDPCC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_PAY_CHANGECONTRACT_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时合同发送数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_PAY_CONTRACT_SEND_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_CONTRACT_SEND_HIS
      (serialno,
       objectno,
       dealdate,
       infotype,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       chgtype,
       contracttype,
       corpno,
       feeitem,
       contractno,
       oribankno,
       oriacctno,
       effectdate,
       changestatus,
       signstatus,
       createtime,
       createdby,
       updatetime,
       updateby,
       channel,
       taskno)
      SELECT serialno,
             objectno,
             dealdate,
             infotype,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             chgtype,
             contracttype,
             corpno,
             feeitem,
             contractno,
             oribankno,
             oriacctno,
             effectdate,
             changestatus,
             signstatus,
             createtime,
             createdby,
             updatetime,
             updateby,
             channel,
             taskno
        FROM DK_PAY_CONTRACT_SEND DPCS
       WHERE DPCS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DPCS.SIGNSTATUS in ('3', '4')
         AND DPCS.TASKNO = p_taskno;
    DELETE FROM DK_PAY_CONTRACT_SEND DDPCS
     WHERE DDPCS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDPCS.SIGNSTATUS in ('3', '4')
       AND DDPCS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_PAY_CONTRACT_SEND_HIS;
  --============================快付通实时签约合同数据转移end================================

  --============================快付通实时代扣数据转移begin===================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时明细数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_DETAIL_HIST
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       memo,
       taskno,
       fundsupplier,
	   bankcode,
	   msg,
	   result,
	   outbatno,
	   dkcode,
	   issendmq,
	   certid)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             memo,
             taskno,
             fundsupplier,
			 bankcode,
	         msg,
	         result,
	         outbatno,
	         dkcode,
	         issendmq,
	         certid
        FROM DK_PAY_DETAIL DPD
       WHERE DPD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DPD.PAYSTATUS in ('4', '5')
         AND DPD.TASKNO = p_taskno;
    DELETE FROM DK_PAY_DETAIL DDPD
     WHERE DDPD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDPD.PAYSTATUS in ('4', '5')
       AND DDPD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时分割数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_SPLIT_HIS(p_taskno IN VARCHAR2, p_days IN NUMBER) IS
  BEGIN
    INSERT INTO DK_PAY_SPLIT_HIST
      (serialno,
       objectno,
       dealdate,
       infotype,
       paychannel,
       paystatus,
       contranctno,
       threadno,
       createtime,
       taskno)
      SELECT serialno,
             objectno,
             dealdate,
             infotype,
             paychannel,
             paystatus,
             contranctno,
             threadno,
             createtime,
             taskno
        FROM DK_PAY_MAIN_SPLIT DPMS
       WHERE DPMS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DPMS.PAYSTATUS in ('4', '5')
         AND DPMS.TASKNO = p_taskno;
    DELETE FROM DK_PAY_MAIN_SPLIT DDPMS
     WHERE DDPMS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDPMS.PAYSTATUS in ('4', '5')
       AND DDPMS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_SPLIT_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时发送数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_SEND_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_SEND_HIS
      (outid,
       subdate,
       corpno,
       transcode,
       productcode,
       feeitem,
       acpbankno,
       acpacctno,
       acpacctname,
       paybankno,
       payacctno,
       payacctname,
       paymoney,
       contractno,
       memo,
       alternameflag,
       sendflag,
       inputdate,
       deduct_channel,
       objectno,
       datescoure,
       threadno,
       createtime,
       createdby,
       updatetime,
       updateby,
       customerid,
       infotype,
       businessdate,
       lasserialno,
       taskno,
       sendoutid)
      SELECT outid,
             subdate,
             corpno,
             transcode,
             productcode,
             feeitem,
             acpbankno,
             acpacctno,
             acpacctname,
             paybankno,
             payacctno,
             payacctname,
             paymoney,
             contractno,
             memo,
             alternameflag,
             sendflag,
             inputdate,
             deduct_channel,
             objectno,
             datescoure,
             threadno,
             createtime,
             createdby,
             updatetime,
             updateby,
             customerid,
             infotype,
             businessdate,
             lasserialno,
             taskno,
             sendoutid
        FROM DK_PAY_SEND DPS
       WHERE DPS.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DPS.SENDFLAG in ('1', '2')
         AND DPS.TASKNO = p_taskno;
    DELETE FROM DK_PAY_SEND DDPS
     WHERE DDPS.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDPS.SENDFLAG in ('1', '2')
       AND DDPS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_SEND_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时接收数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_RECEIVE_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_PAY_RECEIVE_HIS
      (objectno,
       subdate,
       corpno,
       transcode,
       productcode,
       feeitem,
       acpbankno,
       acpacctno,
       acpacctname,
       paybankno,
       payacctno,
       payacctname,
       paymoney,
       contractno,
       memo,
       alternameflag,
       sendflag,
       inputdate,
       deduct_channel,
       datescoure,
       threadno,
       createtime,
       createdby,
       updatetime,
       updateby,
       customerid,
       reqmsgtype,
       reqversion,
       omsgtype,
       oversion,
       setwrkdate,
       otransno,
       outid,
       remark,
       businessdate,
       infotype,
       backstatus,
       lasserialno,
       taskno)
      SELECT objectno,
             subdate,
             corpno,
             transcode,
             productcode,
             feeitem,
             acpbankno,
             acpacctno,
             acpacctname,
             paybankno,
             payacctno,
             payacctname,
             paymoney,
             contractno,
             memo,
             alternameflag,
             sendflag,
             inputdate,
             deduct_channel,
             datescoure,
             threadno,
             createtime,
             createdby,
             updatetime,
             updateby,
             customerid,
             reqmsgtype,
             reqversion,
             omsgtype,
             oversion,
             setwrkdate,
             otransno,
             outid,
             remark,
             businessdate,
             infotype,
             backstatus,
             lasserialno,
             taskno
        FROM DK_PAY_RECEIVE DPC
       WHERE DPC.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DPC.TASKNO = p_taskno;
    DELETE FROM DK_PAY_RECEIVE DDPC
     WHERE DDPC.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDPC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_RECEIVE_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通实时_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_CHARGEFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '1'
         AND DC.RESPTYPE= '0'
         AND NOT EXISTS (SELECT 1 FROM DK_PAY_DETAIL DPDL where DPDL.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDC.RESULT= '1111'
       AND DDC.PAYCHANNEL= '1'
       AND DDC.RESPTYPE= '0'
       AND NOT EXISTS (SELECT 1 FROM DK_PAY_DETAIL DPDL where DPDL.Lasserialno=DDC.LASSERIALNO)
       AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_CHARGEFAIL_HIS;
  --============================快付通实时代扣数据转移end=====================================

  --============================快付通批量代扣数据转移begin====================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量代扣明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_BCHARGE_DETAIL_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       bankcode,
       memo,
       batno,
       taskno,
       fundsupplier,
	   msg,
	   result,
	   outbatno,
	   dkcode,
	   issendmq,
	   certid)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             bankcode,
             memo,
             batno,
             taskno,
             fundsupplier,
			 msg,
             result,
			 outbatno,
			 dkcode,
			 issendmq,
			 certid
        FROM DK_KFT_BATCHCHARGE_DETAIL DKBCD
       WHERE DKBCD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DKBCD.PAYSTATUS in ('4', '5')
         AND DKBCD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_BATCHCHARGE_DETAIL DDKBCD
     WHERE DDKBCD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDKBCD.PAYSTATUS in ('4', '5')
       AND DDKBCD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量代扣发送总表数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_SEND_HIS(p_taskno IN VARCHAR2,
                                     p_days   IN NUMBER) IS
  BEGIN
    INSERT INTO DK_KFT_BCHARGE_SEND_HIS
      (serialno,
       batno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       totalmoney,
       totalnum,
       corpno,
       transcode,
       productcode,
       feeitem,
       bankno,
       accbankno,
       accno,
       accname,
       createtime,
       createdby,
       updatetime,
       updateby,
       bankcode,
       memo,
       paystatus,
       taskno)
      SELECT serialno,
             batno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             totalmoney,
             totalnum,
             corpno,
             transcode,
             productcode,
             feeitem,
             bankno,
             accbankno,
             accno,
             accname,
             createtime,
             createdby,
             updatetime,
             updateby,
             bankcode,
             memo,
             paystatus,
             taskno
        FROM DK_KFT_BATCHCHARGE_SEND DKBCS
       WHERE DKBCS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DKBCS.PAYSTATUS in ('4', '5')
         AND DKBCS.TASKNO = p_taskno;
    DELETE FROM DK_KFT_BATCHCHARGE_SEND DDKBCS
     WHERE DDKBCS.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDKBCS.PAYSTATUS in ('4', '5')
       AND DDKBCS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_SEND_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量代扣发送明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_SNDDETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_BCHARGE_SEND_DETAIL_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       bankcode,
       memo,
       batno,
       taskno,
       sendoutid)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             bankcode,
             memo,
             batno,
             taskno,
             sendoutid
        FROM DK_KFT_BATCHCHARGE_SEND_DETAIL DKBCSD
       WHERE DKBCSD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DKBCSD.PAYSTATUS in ('4', '5')
         AND DKBCSD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_BATCHCHARGE_SEND_DETAIL DDKBCSD
     WHERE DDKBCSD.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDKBCSD.PAYSTATUS in ('4', '5')
       AND DDKBCSD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_SNDDETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量代扣接收总表数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_RECEIVE_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_BCHARGE_RECEIVE_HIS
      (subdate,
       corpno,
       transcode,
       productcode,
       feeitem,
       acpbankno,
       acpacctno,
       acpacctname,
       sendflag,
       deduct_channel,
       createtime,
       createdby,
       updatetime,
       updateby,
       reqmsgtype,
       reqversion,
       omsgtype,
       oversion,
       setwrkdate,
       otransno,
       remark,
       businessdate,
       infotype,
       backstatus,
       netno,
       totalnum,
       totalmoney,
       trnnum,
       trnmoney,
       procode,
       serialno,
       taskno)
      SELECT subdate,
             corpno,
             transcode,
             productcode,
             feeitem,
             acpbankno,
             acpacctno,
             acpacctname,
             sendflag,
             deduct_channel,
             createtime,
             createdby,
             updatetime,
             updateby,
             reqmsgtype,
             reqversion,
             omsgtype,
             oversion,
             setwrkdate,
             otransno,
             remark,
             businessdate,
             infotype,
             backstatus,
             netno,
             totalnum,
             totalmoney,
             trnnum,
             trnmoney,
             procode,
             serialno,
             taskno
        FROM DK_KFT_BATCHCHARGE_RECEIVE DKBCR
       WHERE DKBCR.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DKBCR.TASKNO = p_taskno;
    DELETE FROM DK_KFT_BATCHCHARGE_RECEIVE DDKBCR
     WHERE DDKBCR.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDKBCR.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_RECEIVE_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-03
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_RECDETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_BCHARGE_REC_DETAIL_HIS
      (subdate,
       corpno,
       transcode,
       productcode,
       feeitem,
       acpbankno,
       acpacctno,
       acpacctname,
       paybankno,
       payacctno,
       payacctname,
       paymoney,
       sendflag,
       inputdate,
       deduct_channel,
       createtime,
       createdby,
       updatetime,
       updateby,
       reqmsgtype,
       reqversion,
       omsgtype,
       oversion,
       setwrkdate,
       otransno,
       outid,
       remark,
       businessdate,
       infotype,
       backstatus,
       serialno,
       batno,
       taskno)
      SELECT subdate,
             corpno,
             transcode,
             productcode,
             feeitem,
             acpbankno,
             acpacctno,
             acpacctname,
             paybankno,
             payacctno,
             payacctname,
             paymoney,
             sendflag,
             inputdate,
             deduct_channel,
             createtime,
             createdby,
             updatetime,
             updateby,
             reqmsgtype,
             reqversion,
             omsgtype,
             oversion,
             setwrkdate,
             otransno,
             outid,
             remark,
             businessdate,
             infotype,
             backstatus,
             serialno,
             batno,
             taskno
        FROM DK_KFT_BATCHCHARGE_REC_DETAIL DKBCRD
       WHERE DKBCRD.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DKBCRD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_BATCHCHARGE_REC_DETAIL DDKBCRD
     WHERE DDKBCRD.SUBDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDKBCRD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_RECDETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 快付通批量_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_BDK_KFT_CHARGEFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '1'
         AND DC.RESPTYPE= '1'
         AND NOT EXISTS (SELECT 1 FROM DK_KFT_BATCHCHARGE_DETAIL DKBCD where DKBCD.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDC.RESULT= '1111'
       AND DDC.PAYCHANNEL= '1'
       AND DDC.RESPTYPE= '1'
       AND NOT EXISTS (SELECT 1 FROM DK_KFT_BATCHCHARGE_DETAIL DKBCD where DKBCD.Lasserialno=DDC.LASSERIALNO)
       AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_KFT_CHARGEFAIL_HIS;
  --============================快付通批量代扣数据转移end====================================

  --============================易办事批量代扣数据转移begin======================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易办事批量代扣明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_EBU_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_EBUF_CHARGE_DETAIL_HIS
      (transserialno,
       openbankcode,
       correspondentcode,
       areacode,
       bankname,
       bankaccounttype,
       accounttype,
       bankaccountno,
       bankaccountname,
       certtype,
       certid,
       withholdamt,
       currency,
       payflag,
       contractserialno,
       customerid,
       withholddate,
       paychannel,
       customername,
       withholdfilename,
       lasserialno,
       productid,
       infotype,
       paystatus,
       bankcode,
       taskno,
       fundsupplier,
	   msg,
       result,
	   outbatno,
	   dkcode,
	   issendmq)
      SELECT transserialno,
             openbankcode,
             correspondentcode,
             areacode,
             bankname,
             bankaccounttype,
             accounttype,
             bankaccountno,
             bankaccountname,
             certtype,
             certid,
             withholdamt,
             currency,
             payflag,
             contractserialno,
             customerid,
             withholddate,
             paychannel,
             customername,
             withholdfilename,
             lasserialno,
             productid,
             infotype,
             paystatus,
             bankcode,
             taskno,
             fundsupplier,
             msg,
             result,
             outbatno,
             dkcode,
             issendmq
        FROM DK_EBUF_CHARGE_DETAIL DECD
       WHERE DECD.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DECD.PAYSTATUS in ('4', '5')
         AND DECD.TASKNO = p_taskno;
    DELETE FROM DK_EBUF_CHARGE_DETAIL DDECD
     WHERE DDECD.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDECD.PAYSTATUS in ('4', '5')
       AND DDECD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_EBU_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易办事批量代扣发送总表数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_EBU_SEND_HIS(p_taskno IN VARCHAR2,
                                      p_days   IN NUMBER) IS
  BEGIN
    INSERT INTO DK_EBUF_CHARGE_SEND_HIS
      (batchno,
       totalcount,
       paytotalamt,
       withholddate,
       withholdfilename,
       infotype,
       paystatus,
       orgcode,
       createdate,
       createby,
       taskno)
      SELECT batchno,
             totalcount,
             paytotalamt,
             withholddate,
             withholdfilename,
             infotype,
             paystatus,
             orgcode,
             createdate,
             createby,
             taskno
        FROM DK_EBUF_CHARGE_SEND DECS
       WHERE DECS.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
         AND DECS.PAYSTATUS in ('4', '5')
         AND DECS.TASKNO = p_taskno;
    DELETE FROM DK_EBUF_CHARGE_SEND DDECS
     WHERE DDECS.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYYMMDD')
       AND DDECS.PAYSTATUS in ('4', '5')
       AND DDECS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_EBU_SEND_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易办事批量代扣发送明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_EBU_SNDDETAIL_HIS(p_taskno varchar2,
                                           p_days   number) IS
  BEGIN
    INSERT INTO DK_EBUF_CHARGE_SEND_DETAIL_HIS
      (transserialno,
       openbankcode,
       correspondentcode,
       areacode,
       bankname,
       bankaccounttype,
       accounttype,
       bankaccountno,
       bankaccountname,
       certtype,
       certid,
       withholdamt,
       currency,
       payflag,
       contractserialno,
       customerid,
       withholddate,
       paychannel,
       customername,
       withholdfilename,
       lasserialno,
       productid,
       infotype,
       paystatus,
       orgcode,
       createdate,
       createby,
       taskno,
	   preopenbankcode)
      SELECT transserialno,
             openbankcode,
             correspondentcode,
             areacode,
             bankname,
             bankaccounttype,
             accounttype,
             bankaccountno,
             bankaccountname,
             certtype,
             certid,
             withholdamt,
             currency,
             payflag,
             contractserialno,
             customerid,
             withholddate,
             paychannel,
             customername,
             withholdfilename,
             lasserialno,
             productid,
             infotype,
             paystatus,
             orgcode,
             createdate,
             createby,
             taskno,
	         preopenbankcode
        FROM DK_EBUF_CHARGE_SEND_DETAIL DECSD
       WHERE DECSD.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DECSD.PAYSTATUS in ('4', '5')
         AND DECSD.TASKNO = p_taskno;
    DELETE FROM DK_EBUF_CHARGE_SEND_DETAIL DDECSD
     WHERE DDECSD.WITHHOLDDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDECSD.PAYSTATUS in ('4', '5')
       AND DDECSD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_EBU_SNDDETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易办事批量代扣接收明细数据转移
  --===========================================================================================
  PROCEDURE PRO_BDK_EBU_RECDETAIL_HIS(p_taskno varchar2,
                                           p_days   number) IS
  BEGIN
    INSERT INTO DK_EBUF_CHARGE_REC_DETAIL_HIS
      (serialno,
       openbankcode,
       lineaccount,
       areacode,
       openbankname,
       openaccounttype,
       accounttype,
       replaceaccount,
       replacename,
       certtype,
       certid,
       payamt,
       currency,
       payflag,
       businessinformation,
       remark,
       managereturncode,
       systemrefno,
       manageresultmessage,
       rolloutdate,
       inputdate,
       filename,
       repaymentcollectionfamily,
       withholdfilename,
       lasserialno,
       customerid,
       contractserialno,
       batchno,
       infotype,
       paystatus,
       createdate,
       createby,
       taskno)
      SELECT serialno,
             openbankcode,
             lineaccount,
             areacode,
             openbankname,
             openaccounttype,
             accounttype,
             replaceaccount,
             replacename,
             certtype,
             certid,
             payamt,
             currency,
             payflag,
             businessinformation,
             remark,
             managereturncode,
             systemrefno,
             manageresultmessage,
             rolloutdate,
             inputdate,
             filename,
             repaymentcollectionfamily,
             withholdfilename,
             lasserialno,
             customerid,
             contractserialno,
             batchno,
             infotype,
             paystatus,
             createdate,
             createby,
             taskno
        FROM DK_EBUF_CHARGE_RECEIVE_DETAIL DECRD
       WHERE DECRD.INPUTDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DECRD.TASKNO = p_taskno;
    DELETE FROM DK_EBUF_CHARGE_RECEIVE_DETAIL DDECRD
     WHERE DDECRD.INPUTDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDECRD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_EBU_RECDETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 易办事批量_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_BDK_EBU_CHARGEFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '4'
         AND DC.RESPTYPE= '1'
         AND NOT EXISTS (SELECT 1 FROM DK_EBUF_CHARGE_DETAIL DECD where DECD.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDC.RESULT= '1111'
       AND DDC.PAYCHANNEL= '4'
       AND DDC.RESPTYPE= '1'
       AND NOT EXISTS (SELECT 1 FROM DK_EBUF_CHARGE_DETAIL DECD where DECD.Lasserialno=DDC.LASSERIALNO)
       AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_BDK_EBU_CHARGEFAIL_HIS;
  --============================易办事批量代扣数据转移end====================================

  --============================国采实时代扣数据转移begin===================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 国采实时代扣明细数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_TFB_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_TFB_PAY_DETAIL_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       paymoney,
       payacctno,
       payacctname,
       paybankno,
       paybankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contractno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       bankcode,
       memo,
       mobile,
       cretype,
       creid,
       cardtype,
       sendflag,
       tfbresult,
       retcode,
       retmsg,
       tfbxykvaliddate,
       tfbxykscode,
       spbillno,
       taskno,
       fundsupplier,
	   outbatno,
       issendmq)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             paymoney,
             payacctno,
             payacctname,
             paybankno,
             paybankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contractno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             bankcode,
             memo,
             mobile,
             cretype,
             creid,
             cardtype,
             sendflag,
             tfbresult,
             retcode,
             retmsg,
             tfbxykvaliddate,
             tfbxykscode,
             spbillno,
             taskno,
             fundsupplier,
	         outbatno,
             issendmq
        FROM DK_TFB_PAY_DETAIL DTPD
       WHERE DTPD.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DTPD.SENDFLAG in ('1', '2')
         AND DTPD.TASKNO = p_taskno;
    DELETE FROM DK_TFB_PAY_DETAIL DDTPD
     WHERE DDTPD.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDTPD.SENDFLAG in ('1', '2')
       AND DDTPD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_TFB_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 国采实时代扣发送数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_TFB_SEND_HIS(p_taskno IN VARCHAR2, p_days IN NUMBER) IS
  BEGIN
    INSERT INTO DK_TFB_PAY_SEND_HIS
      (serialno,
       subdate,
       acpbankno,
       acpacctno,
       acpacctname,
       paybankno,
       payacctno,
       payacctname,
       paymoney,
       contractno,
       memo,
       sendflag,
       paychannel,
       objectno,
       createtime,
       createdby,
       updatetime,
       updateby,
       customerid,
       infotype,
       businessdate,
       lasserialno,
       reqmsgtype,
       reqversion,
       spid,
       spbillno,
       tfbcurtype,
       mobile,
       cretype,
       creid,
       cardtype,
       tfbbankname,
       tfbbankno,
       purpose,
       md5sign,
       sendstatus,
       tfbidentifytype,
       tfbbusinesstype,
       tfbbusinessno,
       tfbcardprov,
       tfbxykvaliddate,
       tfbxykscode,
       postscript,
       taskno)
      SELECT serialno,
             subdate,
             acpbankno,
             acpacctno,
             acpacctname,
             paybankno,
             payacctno,
             payacctname,
             paymoney,
             contractno,
             memo,
             sendflag,
             paychannel,
             objectno,
             createtime,
             createdby,
             updatetime,
             updateby,
             customerid,
             infotype,
             businessdate,
             lasserialno,
             reqmsgtype,
             reqversion,
             spid,
             spbillno,
             tfbcurtype,
             mobile,
             cretype,
             creid,
             cardtype,
             tfbbankname,
             tfbbankno,
             purpose,
             md5sign,
             sendstatus,
             tfbidentifytype,
             tfbbusinesstype,
             tfbbusinessno,
             tfbcardprov,
             tfbxykvaliddate,
             tfbxykscode,
             postscript,
             taskno
        FROM DK_TFB_PAY_SEND DTPS
       WHERE DTPS.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DTPS.SENDFLAG in ('1', '2')
         AND DTPS.TASKNO = p_taskno;
    DELETE FROM DK_TFB_PAY_SEND DDTPS
     WHERE DDTPS.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDTPS.SENDFLAG in ('1', '2')
       AND DDTPS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_TFB_SEND_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 国采实时代扣接收数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_TFB_RECEIVE_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_TFB_PAY_RECEIVE_HIS
      (serialno,
       objectno,
       subdate,
       acpbankno,
       acpacctno,
       acpacctname,
       paybankno,
       payacctno,
       payacctname,
       paymoney,
       contractno,
       memo,
       sendflag,
       paychannel,
       createtime,
       createdby,
       updatetime,
       updateby,
       customerid,
       remark,
       businessdate,
       infotype,
       backstatus,
       lasserialno,
       reqmsgtype,
       reqversion,
       spid,
       spbillno,
       tfbcurtype,
       mobile,
       cretype,
       creid,
       cardtype,
       tfbbankname,
       tfbbankno,
       purpose,
       md5sign,
       tfbacplistid,
       settledate,
       tfbresult,
       retcode,
       retmsg,
       tfbidentifytype,
       tfbbusinesstype,
       tfbbusinessno,
       tfbcardprov,
       tfbxykvaliddate,
       tfbxykscode,
       postscript,
       taskno)
      SELECT serialno,
             objectno,
             subdate,
             acpbankno,
             acpacctno,
             acpacctname,
             paybankno,
             payacctno,
             payacctname,
             paymoney,
             contractno,
             memo,
             sendflag,
             paychannel,
             createtime,
             createdby,
             updatetime,
             updateby,
             customerid,
             remark,
             businessdate,
             infotype,
             backstatus,
             lasserialno,
             reqmsgtype,
             reqversion,
             spid,
             spbillno,
             tfbcurtype,
             mobile,
             cretype,
             creid,
             cardtype,
             tfbbankname,
             tfbbankno,
             purpose,
             md5sign,
             tfbacplistid,
             settledate,
             tfbresult,
             retcode,
             retmsg,
             tfbidentifytype,
             tfbbusinesstype,
             tfbbusinessno,
             tfbcardprov,
             tfbxykvaliddate,
             tfbxykscode,
             postscript,
             taskno
        FROM DK_TFB_PAY_RECEIVE DTPR
       WHERE DTPR.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DTPR.SENDFLAG in ('1', '2')
         AND DTPR.TASKNO = p_taskno;
    DELETE FROM DK_TFB_PAY_RECEIVE DDTPR
     WHERE DDTPR.BUSINESSDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDTPR.SENDFLAG in ('1', '2')
       AND DDTPR.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_TFB_RECEIVE_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 国采实时_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_DK_TFB_CHARGEFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '5'
         AND DC.RESPTYPE= '0'
         AND NOT EXISTS (SELECT 1 FROM DK_TFB_PAY_DETAIL DTPD where DTPD.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDC.RESULT= '1111'
       AND DDC.PAYCHANNEL= '5'
       AND DDC.RESPTYPE= '0'
       AND NOT EXISTS (SELECT 1 FROM DK_TFB_PAY_DETAIL DTPD where DTPD.Lasserialno=DDC.LASSERIALNO)
       AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_TFB_CHARGEFAIL_HIS;
  --============================国采实时代扣数据转移end=====================================

  --============================新快付通实时代扣数据转移begin===================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通实时代扣明细数据转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_NEW_RT_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_NEW_RT_DETAIL_HIS
    (serialno,
     biztype,
     tradename,
     amount,
     currency,
     custbankname,
     custbankno,
     custbankaccountno,
     custname,
     custcertificationtype,
     custid,
     merchantbankaccountno,
     result,
     dkcode,
     dkremark,
     issendmq,
     outbatno,
     lasserialno,
     infotype,
     paychannel,
     paystatus,
     taskno,
     createtime,
     updatetime,
     custbankaccttype,
     exceptioninfo,
     exceptionnum,
	 bankcode)
     SELECT serialno,
     biztype,
     tradename,
     amount,
     currency,
     custbankname,
     custbankno,
     custbankaccountno,
     custname,
     custcertificationtype,
     custid,
     merchantbankaccountno,
     result,
     dkcode,
     dkremark,
     issendmq,
     outbatno,
     lasserialno,
     infotype,
     paychannel,
     paystatus,
     taskno,
     createtime,
     updatetime,
     custbankaccttype,
     exceptioninfo,
     exceptionnum,
	 bankcode
        FROM DK_KFT_NEW_RT_CHARGE_DETAIL DKNRCD
       WHERE DKNRCD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNRCD.RESULT in ('0000', '1111')
         AND DKNRCD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_NEW_RT_CHARGE_DETAIL DKNRCD
     WHERE DKNRCD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNRCD.RESULT in ('0000', '1111')
         AND DKNRCD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_NEW_RT_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通实时_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_DK_KFT_NEW_RT_CFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '6'
         AND DC.RESPTYPE= '0'
         AND NOT EXISTS (SELECT 1 FROM DK_KFT_NEW_RT_CHARGE_DETAIL DKNRCD where DKNRCD.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DDC.RESULT= '1111'
         AND DDC.PAYCHANNEL= '6'
         AND DDC.RESPTYPE= '0'
         AND NOT EXISTS (SELECT 1 FROM DK_KFT_NEW_RT_CHARGE_DETAIL DKNRCD where DKNRCD.Lasserialno=DDC.LASSERIALNO)
         AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_KFT_NEW_RT_CFAIL_HIS;
  --============================新快付通实时代扣数据转移end=====================================

  --============================新快付通批量代扣数据转移begin====================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通批量代扣明细数据转移
  --===========================================================================================
  PROCEDURE PRO_KFT_NEW_BC_DETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_NEW_BATCH_DETAIL_HIS
      (serialno,
       biztype,
       tradename,
      amount,
      currency,
      custbankname,
      custbankno,
      custbankaccountno,
      custname,
      custcertificationtype,
      custid,
      merchantbankaccountno,
      result,
      dkcode,
      dkremark,
      issendmq,
      outbatno,
      lasserialno,
      infotype,
      paychannel,
      paystatus,
      taskno,
      createtime,
      updatetime,
      custbankaccttype,
      bankcode,
	  batchno)
      SELECT serialno,
      biztype,
      tradename,
      amount,
      currency,
      custbankname,
      custbankno,
      custbankaccountno,
      custname,
      custcertificationtype,
      custid,
      merchantbankaccountno,
      result,
      dkcode,
      dkremark,
      issendmq,
      outbatno,
      lasserialno,
      infotype,
      paychannel,
      paystatus,
      taskno,
      createtime,
      updatetime,
      custbankaccttype,
      bankcode,
	  batchno
        FROM DK_KFT_NEW_BATCH_CHARGE_DETAIL DKNBCD
       WHERE DKNBCD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCD.RESULT in ('0000', '1111')
         AND DKNBCD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_NEW_BATCH_CHARGE_DETAIL DKNBCD
     WHERE DKNBCD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCD.RESULT in ('0000', '1111')
         AND DKNBCD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_KFT_NEW_BC_DETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通批量代扣发送总表数据转移
  --===========================================================================================
  PROCEDURE PRO_KFT_NEW_BC_SEND_HIS(p_taskno IN VARCHAR2,
                                     p_days   IN NUMBER) IS
  BEGIN
    INSERT INTO DK_KFT_NEW_BATCH_SEND_HIS
      (batchno,
       totalamount,
       countrecord,
       merchantbankaccountno,
       biztype,
       paystatus,
       exceptioninfo,
       taskno,
       createtime,
       updatetime,
       exceptionnum)
      SELECT batchno,
       totalamount,
       countrecord,
       merchantbankaccountno,
       biztype,
       paystatus,
       exceptioninfo,
       taskno,
       createtime,
       updatetime,
       exceptionnum
        FROM DK_KFT_NEW_BATCH_SEND DKNBCS
       WHERE DKNBCS.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCS.PAYSTATUS = '4'
         AND DKNBCS.TASKNO = p_taskno;
    DELETE FROM DK_KFT_NEW_BATCH_SEND DKNBCS
     WHERE DKNBCS.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCS.PAYSTATUS = '4'
         AND DKNBCS.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_KFT_NEW_BC_SEND_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通批量代扣发送明细数据转移
  --===========================================================================================
  PROCEDURE PRO_KFT_NEW_BC_SDETAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_KFT_NEW_BATCH_SDETAIL_HIS
      (orderno,
       batchno,
       outbatno,
       lasserialno,
       amount,
       status,
       merchantbankaccountno,
       bankreturntime,
       errorcode,
       errormsg,
       createtime,
       updatetime)
      SELECT orderno,
       batchno,
       outbatno,
       lasserialno,
       amount,
       status,
       merchantbankaccountno,
       bankreturntime,
       errorcode,
       errormsg,
       createtime,
       updatetime
        FROM DK_KFT_NEW_BATCH_SEND_DETAIL DKNBCSD
       WHERE DKNBCSD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCSD.STATUS in ('1', '2')
         AND DKNBCSD.TASKNO = p_taskno;
    DELETE FROM DK_KFT_NEW_BATCH_SEND_DETAIL DKNBCSD
     WHERE DKNBCSD.CREATETIME < TO_DATE(TO_CHAR(SYSDATE - p_days, 'yyyy/MM/dd'),'yyyy/MM/dd')
         AND DKNBCSD.STATUS in ('1', '2')
         AND DKNBCSD.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_KFT_NEW_BC_SDETAIL_HIS;
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 新快付通批量_代扣总表数据(代扣失败)转移
  --===========================================================================================
  PROCEDURE PRO_KFT_NEW_BC_CHARGEFAIL_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT= '1111'
         AND DC.PAYCHANNEL= '7'
         AND DC.RESPTYPE= '1'
         AND NOT EXISTS (SELECT 1 FROM DK_KFT_NEW_BATCH_CHARGE_DETAIL DKNBCD where DKNBCD.Lasserialno=DC.LASSERIALNO)
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DDC.RESULT= '1111'
         AND DDC.PAYCHANNEL= '7'
         AND DDC.RESPTYPE= '1'
         AND NOT EXISTS (SELECT 1 FROM DK_KFT_NEW_BATCH_CHARGE_DETAIL DKNBCD where DKNBCD.Lasserialno=DDC.LASSERIALNO)
         AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_KFT_NEW_BC_CHARGEFAIL_HIS;
  --============================新快付通批量代扣数据转移end====================================

  --============================代扣总表数据转移end=====================================
  --===========================================================================================
  -- author  : chenliang 2017-05-06
  -- p_taskno: 任务编号
  -- p_days  : 间隔天数
  -- descript: 代扣总表数据(代扣成功)转移
  --===========================================================================================
  PROCEDURE PRO_DK_CHARGESUCCESS_HIS(p_taskno varchar2, p_days number) IS
  BEGIN
    INSERT INTO DK_CHARGE_HIS
      (serialno,
       objectno,
       dealdate,
       businessdate,
       batchtranstype,
       infotype,
       paychannel,
       paycurrency,
       payamt,
       payacctno,
       payacctname,
       payacctbankno,
       payacctbankname,
       acpbankno,
       acpbankname,
       acpacctno,
       acpacctname,
       paystatus,
       customerid,
       contranctno,
       createtime,
       createdby,
       updatetime,
       updateby,
       lasserialno,
       channel,
       outbatno,
       batno,
       msg,
       result,
       resptype,
       bankcode,
       sendflag,
       areacode,
       distribute,
       specialchannel,
       fundsupplier,
       taskno,
	   dkcode,
	   certid,
	   sendtomq,
	   isexception,
	   payaccttype,
	   businessscenario)
      SELECT serialno,
             objectno,
             dealdate,
             businessdate,
             batchtranstype,
             infotype,
             paychannel,
             paycurrency,
             payamt,
             payacctno,
             payacctname,
             payacctbankno,
             payacctbankname,
             acpbankno,
             acpbankname,
             acpacctno,
             acpacctname,
             paystatus,
             customerid,
             contranctno,
             createtime,
             createdby,
             updatetime,
             updateby,
             lasserialno,
             channel,
             outbatno,
             batno,
             msg,
             result,
             resptype,
             bankcode,
             sendflag,
             areacode,
             distribute,
             specialchannel,
             fundsupplier,
             taskno,
	         dkcode,
	         certid,
	         sendtomq,
	         isexception,
	         payaccttype,
	         businessscenario
        FROM DK_CHARGE DC
       WHERE DC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
         AND DC.RESULT='0000'
         AND DC.TASKNO = p_taskno;
    DELETE FROM DK_CHARGE DDC
     WHERE DDC.DEALDATE < TO_CHAR(SYSDATE - p_days, 'YYYY/MM/DD')
       AND DDC.RESULT='0000'
       AND DDC.TASKNO = p_taskno;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END PRO_DK_CHARGESUCCESS_HIS;
  --============================代扣总表数据转移end=====================================

END PKG_YK_QY_DK_HIS;

/
